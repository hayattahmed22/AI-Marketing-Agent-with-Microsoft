# AutoNet Car Caption AI Agent 🚗🤖

A lightweight AI-style automation project that converts structured vehicle catalog data into ready-to-post Instagram ad captions.

This project was built for automotive social media marketing, especially for dealerships/export businesses that need to quickly turn car inventory into clean, high-converting captions.

## What it does

- Reads a car catalog from Excel or CSV
- Extracts vehicle details like make, model, mileage, price, colors, engine, and stock number
- Generates a polished Instagram caption for each vehicle
- Exports the captions into easy copy-paste formats
- Keeps the original catalog separate from the social media output

## Project structure

```text
autonet-car-caption-ai-agent/
├── data/
│   └── sample_car_catalog.xlsx
├── outputs/
│   ├── instagram_captions_copy_paste.txt
│   ├── instagram_captions.md
│   ├── generated_captions.csv
│   └── generated_instagram_captions.xlsx
├── src/
│   ├── car_caption_agent.py
│   └── agent_prompt.txt
├── workflow/
│   └── n8n_workflow_blueprint.json
├── requirements.txt
├── .gitignore
└── README.md
```

## Example output

```text
🚗 2020 Ford Ranger now available!

This used bakkie is built for strength, practicality, and both work and lifestyle use.

✅ Mileage: 60000 km
✅ Engine: 2.2L Diesel
✅ Transmission: Automatic
✅ Drivetrain: RWD
✅ Exterior: Blue
✅ Interior: Black
✅ Stock No: 23457

💰 Price: R410,000

We assist with export and paperwork for Zimbabwe, Botswana, Zambia, and nearby countries.

📩 DM us today to secure this vehicle before it’s gone.

#Ford #Ranger #CarForSale #UsedCars #AutoNet #SouthAfricaCars #ZimbabweCars #BotswanaCars #ZambiaCars #ExportCars #CarDeals
```

## How to run

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the caption generator:

```bash
python src/car_caption_agent.py --input data/sample_car_catalog.xlsx --output outputs/generated_captions.csv
```

## Why this project is useful

Car dealerships often have inventory data sitting in spreadsheets, but creating captions manually takes time. This project turns that inventory into social media-ready marketing content automatically.

It can be expanded into:
- a full dealership content pipeline
- an n8n automation workflow
- a Supabase inventory database
- a web dashboard
- automated Instagram/Facebook posting

## Tech stack

- Python
- Pandas
- OpenPyXL
- Spreadsheet automation
- Prompt engineering
- n8n workflow planning

## Future improvements

- Add OpenAI API integration for more advanced caption variation
- Generate multiple caption styles per vehicle
- Add Canva/social post template automation
- Connect to Supabase inventory
- Auto-post captions to Instagram/Facebook
- Add image-to-caption support for vehicle photos

## Disclaimer

The sample vehicle data is generated for demo/project purposes.
