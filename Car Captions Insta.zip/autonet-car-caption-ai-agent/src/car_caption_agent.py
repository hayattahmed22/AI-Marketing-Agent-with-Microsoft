"""
AutoNet Car Caption AI Agent

Reads a car catalog CSV/XLSX file and generates Instagram ad captions
for each vehicle listing.

Usage:
    python src/car_caption_agent.py --input data/sample_car_catalog.xlsx --output outputs/generated_captions.csv
"""

import argparse
from pathlib import Path
import pandas as pd


def build_caption(car: dict) -> str:
    """Generate an Instagram caption from one car listing row."""

    make = car.get("Make", "")
    model = car.get("Model", "")
    year = car.get("Year", "")
    body = str(car.get("Body Style", "")).lower()
    condition = str(car.get("Condition", "used")).lower()
    mileage = car.get("Mileage", "")
    engine_capacity = car.get("Engine Capacity", "")
    fuel = car.get("Fuel Type", "")
    transmission = car.get("Transmission", "")
    drivetrain = car.get("Drivetrain", "")
    exterior = car.get("Exterior Color", "")
    interior = car.get("Interior Color", "")
    price = car.get("Price", "")
    stock = car.get("Stock Number", "")

    if body == "suv":
        intro = f"This {condition} SUV is perfect for buyers who want comfort, space, and strong road presence."
    elif body == "hatchback":
        intro = f"This {condition} hatchback is ideal for city driving, fuel saving, and everyday convenience."
    elif body == "bakkie":
        intro = f"This {condition} bakkie is built for strength, practicality, and both work and lifestyle use."
    elif make in ["BMW", "Mercedes-Benz", "Audi"]:
        intro = f"This {condition} vehicle gives you a premium look, smooth drive, and luxury feel."
    else:
        intro = f"This {condition} {body or 'vehicle'} is clean, stylish, and ready for its next owner."

    hashtags = [
        f"#{str(make).replace('-', '').replace(' ', '')}",
        f"#{str(model).replace('-', '').replace(' ', '')}",
        "#CarForSale",
        "#UsedCars",
        "#AutoNet",
        "#SouthAfricaCars",
        "#ZimbabweCars",
        "#BotswanaCars",
        "#ZambiaCars",
        "#ExportCars",
        "#CarDeals",
    ]

    return f"""🚗 {year} {make} {model} now available!

{intro}

✅ Mileage: {mileage}
✅ Engine: {engine_capacity} {fuel}
✅ Transmission: {transmission}
✅ Drivetrain: {drivetrain}
✅ Exterior: {exterior}
✅ Interior: {interior}
✅ Stock No: {stock}

💰 Price: {price}

We assist with export and paperwork for Zimbabwe, Botswana, Zambia, and nearby countries.

📩 DM us today to secure this vehicle before it’s gone.

{" ".join(hashtags)}"""


def read_catalog(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(path)
    raise ValueError("Input file must be .csv, .xlsx, or .xls")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate Instagram captions from a vehicle catalog.")
    parser.add_argument("--input", required=True, help="Path to car catalog file")
    parser.add_argument("--output", required=True, help="Path to save generated captions CSV")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    df = read_catalog(input_path)
    df["Instagram Caption"] = df.apply(lambda row: build_caption(row.to_dict()), axis=1)

    export_columns = [
        "Make", "Model", "Year", "Stock Number", "Price", "Mileage", "Instagram Caption"
    ]
    available_columns = [col for col in export_columns if col in df.columns]
    df[available_columns].to_csv(output_path, index=False)

    print(f"Generated {len(df)} captions.")
    print(f"Saved to: {output_path}")


if __name__ == "__main__":
    main()
